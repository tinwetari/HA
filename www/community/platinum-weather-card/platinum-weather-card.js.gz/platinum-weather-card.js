export{P as PlatinumWeatherCard}from"./platinum-weather-card-df6d26e2.js";
